import React from "react";
const variantClasses = {
  h1: "font-medium sm:text-[27px] md:text-[29px] text-[31px]",
  h2: "font-light sm:text-[21px] md:text-[23px] text-[25px]",
  h3: "font-semibold text-[20px]",
  h4: "text-[16px]",
  h5: "font-light text-[12px]",
};
const Text = ({ children, className, variant, as, ...restProps }) => {
  const Component = as || "span";
  return (
    <Component
      className={`${className} ${variantClasses[variant]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
