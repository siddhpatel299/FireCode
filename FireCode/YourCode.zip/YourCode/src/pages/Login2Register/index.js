import React from "react";

import { Text, Stack, Img, Input, Button } from "components";

const Login2RegisterPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col font-poppins gap-[28px] justify-center mx-[auto] p-[15px] w-[100%]">
        <Text
          className="md:ml-[0] sm:ml-[0] ml-[27px] mr-[1283px] mt-[23px] text-black_900 text-left w-[auto]"
          as="h3"
          variant="h3"
        >
          Your Logo
        </Text>
        <div className="flex flex-col items-end max-w-[1383px] mb-[39px] md:ml-[0] sm:ml-[0] ml-[auto] mr-[auto] md:pl-[20px] sm:pl-[20px] pl-[69px] md:pr-[20px] sm:pr-[20px] w-[100%]">
          <Stack className="h-[757px] relative w-[100%]">
            <Img
              src="images/img_smallteamdisc.svg"
              className="absolute h-[650px] right-[0] top-[5%] w-[auto]"
              alt="smallteamdisc"
            />
            <div className="absolute flex flex-col h-[max-content] inset-y-[0] items-center justify-start left-[0] my-[auto] w-[39%]">
              <div className="bg-white_A700 border border-bluegray_400 border-solid flex flex-col items-center justify-start p-[20px] rounded-radius10 shadow-bs w-[100%]">
                <div className="flex flex-col items-start justify-start mb-[4px] md:w-[100%] sm:w-[100%] w-[91%]">
                  <Text
                    className="text-black_900 text-left w-[auto]"
                    as="h2"
                    variant="h2"
                  >
                    Welcome !
                  </Text>
                  <div className="flex flex-col gap-[6px] items-start justify-start mt-[26px] md:w-[100%] sm:w-[100%] w-[43%]">
                    <Text
                      className="text-black_900 text-left w-[auto]"
                      as="h1"
                      variant="h1"
                    >
                      Sign up to{" "}
                    </Text>
                    <Text
                      className="font-normal not-italic text-black_900 text-left w-[auto]"
                      as="h4"
                      variant="h4"
                    >
                      Lorem Ipsum is simply{" "}
                    </Text>
                  </div>
                  <div className="flex flex-col items-center justify-start mt-[26px] w-[100%]">
                    <div className="flex flex-col gap-[13px] items-start justify-start pt-[3px] w-[100%]">
                      <Text
                        className="font-normal not-italic text-black_900 text-left w-[auto]"
                        as="h4"
                        variant="h4"
                      >
                        Email
                      </Text>
                      <Input
                        className="font-light leading-[normal] p-[0] text-[14px] placeholder:text-gray_500 text-gray_500 text-left w-[100%]"
                        wrapClassName="w-[100%]"
                        type="email"
                        name="GroupTwenty"
                        placeholder="Enter your email"
                      ></Input>
                    </div>
                    <div className="flex flex-col gap-[12px] items-start justify-start mt-[24px] pt-[4px] w-[100%]">
                      <Text
                        className="font-normal not-italic text-black_900 text-left w-[auto]"
                        as="h4"
                        variant="h4"
                      >
                        User name
                      </Text>
                      <Input
                        className="font-light leading-[normal] p-[0] text-[14px] placeholder:text-gray_500 text-gray_500 text-left w-[100%]"
                        wrapClassName="w-[100%]"
                        type="text"
                        name="GroupTwenty One"
                        placeholder="Enter your user name"
                      ></Input>
                    </div>
                    <div className="flex flex-col items-center justify-start mt-[24px] w-[100%]">
                      <div className="flex flex-col gap-[13px] items-start justify-start pt-[4px] w-[100%]">
                        <Text
                          className="font-normal not-italic text-black_900 text-left w-[auto]"
                          as="h4"
                          variant="h4"
                        >
                          Password
                        </Text>
                        <Input
                          className="font-light leading-[normal] p-[0] text-[14px] placeholder:text-gray_500 text-gray_500 text-left w-[100%]"
                          wrapClassName="flex w-[100%]"
                          type="password"
                          name="GroupTwenty Two"
                          placeholder="Enter your Password"
                          suffix={
                            <Img
                              src="images/img_eye.svg"
                              className="ml-[12px] my-[auto]"
                              alt="eye"
                            />
                          }
                          size="md"
                        ></Input>
                      </div>
                    </div>
                    <div className="flex flex-col items-center justify-start mt-[24px] w-[100%]">
                      <div className="flex flex-col gap-[13px] items-start justify-start pt-[3px] w-[100%]">
                        <Text
                          className="font-normal not-italic text-black_900 text-left w-[auto]"
                          as="h4"
                          variant="h4"
                        >
                          Confrim Password
                        </Text>
                        <Input
                          className="font-light leading-[normal] p-[0] text-[14px] placeholder:text-gray_500 text-gray_500 text-left w-[100%]"
                          wrapClassName="flex w-[100%]"
                          type="password"
                          name="GroupTwenty Three"
                          placeholder="Confrim your Password"
                          suffix={
                            <Img
                              src="images/img_eye.svg"
                              className="ml-[35px] my-[auto]"
                              alt="eye"
                            />
                          }
                          size="md"
                        ></Input>
                      </div>
                    </div>
                    <Button className="cursor-pointer font-medium leading-[normal] mt-[31px] text-[16px] text-center text-white_A700 w-[100%]">
                      Register
                    </Button>
                  </div>
                  <Text
                    className="font-light md:ml-[0] sm:ml-[0] ml-[69px] mt-[25px] text-black_900 text-left w-[auto]"
                    as="h4"
                    variant="h4"
                  >
                    <span className="text-gray_600 text-[16px] font-poppins">
                      Already have an Account ?
                    </span>
                    <span className="text-black_900 text-[16px] font-poppins font-semibold">
                      {" "}
                      Register
                    </span>
                  </Text>
                </div>
              </div>
            </div>
          </Stack>
        </div>
      </div>
    </>
  );
};

export default Login2RegisterPage;
