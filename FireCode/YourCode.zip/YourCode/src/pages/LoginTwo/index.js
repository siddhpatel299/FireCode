import React from "react";

import { Text, Stack, Img, Input, CheckBox, Button } from "components";

const LoginTwoPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col font-poppins gap-[53px] justify-start mx-[auto] p-[15px] w-[100%]">
        <Text
          className="md:ml-[0] sm:ml-[0] ml-[27px] mt-[23px] text-black_900 text-left w-[auto]"
          as="h3"
          variant="h3"
        >
          Your Logo
        </Text>
        <div className="flex flex-col items-end max-w-[1383px] mb-[70px] md:ml-[0] sm:ml-[0] ml-[auto] mr-[auto] md:pl-[20px] sm:pl-[20px] pl-[69px] md:pr-[20px] sm:pr-[20px] w-[100%]">
          <Stack className="h-[701px] relative w-[100%]">
            <Img
              src="images/img_smallteamdisc.svg"
              className="absolute h-[650px] inset-y-[0] my-[auto] right-[0] w-[auto]"
              alt="smallteamdisc"
            />
            <div className="absolute flex flex-col h-[max-content] inset-y-[0] items-center justify-start left-[0] my-[auto] w-[39%]">
              <div className="bg-white_A700 border border-bluegray_400 border-solid flex flex-col items-center justify-start p-[35px] sm:px-[20px] rounded-radius10 shadow-bs w-[100%]">
                <div className="flex flex-col items-start justify-start my-[6px] md:w-[100%] sm:w-[100%] w-[98%]">
                  <Text
                    className="text-black_900 text-left w-[auto]"
                    as="h2"
                    variant="h2"
                  >
                    Welcome !
                  </Text>
                  <div className="flex flex-col gap-[6px] items-start justify-start mt-[45px] md:w-[100%] sm:w-[100%] w-[43%]">
                    <Text
                      className="text-black_900 text-left w-[auto]"
                      as="h1"
                      variant="h1"
                    >
                      Sign in to{" "}
                    </Text>
                    <Text
                      className="font-normal not-italic text-black_900 text-left w-[auto]"
                      as="h4"
                      variant="h4"
                    >
                      Lorem Ipsum is simply{" "}
                    </Text>
                  </div>
                  <div className="flex flex-col items-center justify-start mt-[48px] w-[100%]">
                    <div className="flex flex-col gap-[12px] items-start justify-start pt-[4px] w-[100%]">
                      <Text
                        className="font-normal not-italic text-black_900 text-left w-[auto]"
                        as="h4"
                        variant="h4"
                      >
                        User name
                      </Text>
                      <Input
                        className="font-light leading-[normal] p-[0] text-[14px] placeholder:text-gray_500 text-gray_500 text-left w-[100%]"
                        wrapClassName="w-[100%]"
                        type="text"
                        name="GroupTwenty"
                        placeholder="Enter your user name"
                      ></Input>
                    </div>
                    <div className="flex flex-col items-center justify-start mt-[38px] w-[100%]">
                      <div className="flex flex-col gap-[13px] items-start justify-start pt-[4px] w-[100%]">
                        <Text
                          className="font-normal not-italic text-black_900 text-left w-[auto]"
                          as="h4"
                          variant="h4"
                        >
                          Password
                        </Text>
                        <Input
                          className="font-light leading-[normal] p-[0] text-[14px] placeholder:text-gray_500 text-gray_500 text-left w-[100%]"
                          wrapClassName="flex w-[100%]"
                          type="password"
                          name="GroupTwenty One"
                          placeholder="Enter your Password"
                          suffix={
                            <Img
                              src="images/img_eye.svg"
                              className="ml-[12px] my-[auto]"
                              alt="eye"
                            />
                          }
                          size="md"
                        ></Input>
                      </div>
                    </div>
                    <div className="flex flex-row items-start justify-between mt-[25px] w-[100%]">
                      <CheckBox
                        className="font-light leading-[normal] text-[12px] text-black_900 text-left"
                        inputClassName="h-[15px] mr-[5px] w-[15px]"
                        name="Rememebrme"
                        label="Rememebr me"
                      ></CheckBox>
                      <Text
                        className="text-gray_800 text-left w-[auto]"
                        as="h5"
                        variant="h5"
                      >
                        Forgot Password ?
                      </Text>
                    </div>
                    <Button className="cursor-pointer font-medium leading-[normal] mt-[38px] text-[16px] text-center text-white_A700 w-[100%]">
                      Login
                    </Button>
                  </div>
                  <Text
                    className="font-light md:ml-[0] sm:ml-[0] ml-[77px] mt-[61px] text-black_900 text-left w-[auto]"
                    as="h4"
                    variant="h4"
                  >
                    <span className="text-gray_600 text-[16px] font-poppins">
                      Don’y have an Account ?
                    </span>
                    <span className="text-black_900 text-[16px] font-poppins font-semibold">
                      {" "}
                      Register
                    </span>
                  </Text>
                </div>
              </div>
            </div>
          </Stack>
        </div>
      </div>
    </>
  );
};

export default LoginTwoPage;
