module.exports = {
  mode: "jit",
  content: [
    "./src/**/**/*.{js,ts,jsx,tsx,html,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,html,mdx}",
  ],
  darkMode: "class",
  theme: {
    screens: {
      sm: { min: "200px", max: "550px" },
      md: { min: "551px", max: "1050px" },
    },
    extend: {
      colors: {
        gray_600: "#7d7d7d",
        gray_500: "#ababab",
        black_900: "#000000",
        bluegray_400: "#868686",
        gray_800: "#4c4c4c",
        black_901: "#020202",
        gray_900: "#282828",
        black_900_0c: "#0000000c",
        white_A700: "#ffffff",
      },
      borderRadius: { radius6: "6px", radius10: "10px" },
      fontFamily: { poppins: "Poppins" },
      boxShadow: { bs: "0px 4px  64px 0px #0000000c" },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
